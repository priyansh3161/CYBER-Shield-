============================================================
                     CRYPTOSCOPE
                COMPLETE SETUP PACKAGE
============================================================

Cryptoscope is a hybrid cybersecurity and email cryptographic
forensics platform designed for PCAP analysis and real-time
network traffic monitoring.

This package contains the files required to run the Cryptoscope
dashboard and its local real-time monitoring engine on Windows.

------------------------------------------------------------
PACKAGE CONTENTS
------------------------------------------------------------

1. rt_engine.exe
   Cryptoscope Local C++ Real-Time Monitoring Engine.

2. Cryptoscopedashboard.html
   Cryptoscope web dashboard used to view monitoring,
   security findings, risk information and reports.

3. Npcap-Installer.exe
   Packet-capture dependency required by the local engine
   for real-time network traffic monitoring.

4. INSTALLATION_GUIDE.pdf
   Detailed installation and setup instructions.

------------------------------------------------------------
SYSTEM REQUIREMENTS
------------------------------------------------------------

Operating System:
- Windows 10 / Windows 11
- 64-bit Windows recommended

Required:
- Npcap
- Active network interface
- Administrator privileges may be required for packet capture

Internet connection:
- Required for cloud-connected features and live communication
  with the Cryptoscope cloud infrastructure.

------------------------------------------------------------
INSTALLATION
------------------------------------------------------------

STEP 1 — INSTALL NPCAP
----------------------

Run:

    Npcap-Installer.exe

Follow the Npcap installation wizard.

For live packet capture, allow Npcap to install its packet
capture support for the Windows networking stack.

If Windows asks for administrator permission, allow the
installation to continue.


STEP 2 — KEEP THE FILES TOGETHER
--------------------------------

Keep the following files in the same folder:

    rt_engine.exe
    Cryptoscopedashboard.html

Do not rename the engine executable unless you also update
the corresponding commands/configuration.


STEP 3 — TEST THE LOCAL ENGINE
------------------------------

Open Command Prompt in the folder containing rt_engine.exe.

Run:

    rt_engine.exe --self-test

The self-test is used to verify that the local engine can
start correctly before beginning live monitoring.


STEP 4 — START THE LOCAL ENGINE
-------------------------------

The engine can be started using:

    rt_engine.exe <interface> [cloud_endpoint_url]

Replace <interface> with the Windows network interface that
you want to monitor.

Example:

    rt_engine.exe "Ethernet" <cloud endpoint>

The cloud endpoint is used when live engine events need to
be forwarded to the Cryptoscope cloud infrastructure.


STEP 5 — OPEN THE DASHBOARD
---------------------------

Open:

    Cryptoscopedashboard.html

in a modern web browser.

Recommended browsers:

- Google Chrome
- Microsoft Edge


STEP 6 — START LIVE MONITORING
------------------------------

Inside the Cryptoscope dashboard:

    Live Monitoring
          ↓
    Start / Monitor
          ↓
    View real-time security events

The local C++ engine monitors network traffic and reports
suspicious activity to the Cryptoscope platform.


------------------------------------------------------------
HOW CRYPTOSCOPE WORKS
------------------------------------------------------------

Cryptoscope uses a hybrid Local + Cloud architecture.

LOCAL C++ ENGINE
----------------

The Local Engine runs directly on the user's Windows system.

Its primary purpose is real-time network traffic screening.

    Network Traffic
          ↓
    Local C++ Engine
          ↓
    Packet Inspection
          ↓
    Security Checks
          ↓
    Suspicious Events
          ↓
    Cryptoscope Cloud


CLOUD FORENSIC ENGINE
---------------------

PCAP files can be processed by the cloud-based Python forensic
pipeline for deeper analysis.

    PCAP File
        ↓
    Cloud Processing
        ↓
    Forensic Analysis
        ↓
    Security Assessment
        ↓
    Findings + Risk Score
        ↓
    Cryptoscope Dashboard


CLOUD SERVER
------------

The Cryptoscope cloud infrastructure acts as the central
communication and processing layer.

It connects the local real-time engine with the dashboard,
handles cloud-based forensic processing, stores security
information and provides real-time updates to connected
clients.


DATABASE
--------

Security events and historical analysis information are stored
in the platform's cloud database so that previous alerts,
threat information and analysis results can be displayed
through the dashboard.


------------------------------------------------------------
PCAP ANALYSIS
------------------------------------------------------------

Cryptoscope can analyze PCAP / PCAPNG captures for security
and cryptographic indicators.

The analysis can include:

- Network protocols
- TCP streams
- STARTTLS activity
- TLS handshake information
- Cryptographic characteristics
- Certificates
- Suspicious or anomalous activity
- Security findings
- Risk assessment

The resulting analysis can be viewed through the dashboard
and exported as a forensic report.


------------------------------------------------------------
REAL-TIME MONITORING
------------------------------------------------------------

The Local C++ Engine is designed for continuous network
traffic monitoring.

When suspicious activity is detected:

    Network
       ↓
    Local Engine
       ↓
    Security Event
       ↓
    Cloud Infrastructure
       ↓
    Dashboard
       ↓
    Real-Time Alert


------------------------------------------------------------
IMPORTANT
------------------------------------------------------------

• Install Npcap before starting live packet monitoring.

• Run the self-test before using the engine for the first time.

• Make sure the correct network interface is selected.

• Windows Firewall or security software may ask for network
  permissions.

• Do not share private cloud credentials or secret keys.

• Do not modify the engine configuration unless you know
  the required settings.

• The dashboard and local engine should remain compatible
  with the same Cryptoscope release.


------------------------------------------------------------
QUICK START
------------------------------------------------------------

For experienced users:

1. Install Npcap.
2. Open Command Prompt in the Cryptoscope folder.
3. Run:

       rt_engine.exe --self-test

4. Start the engine using the appropriate network interface.
5. Open:

       Cryptoscopedashboard.html

6. Go to:

       Live Monitoring


------------------------------------------------------------
SUPPORT / TROUBLESHOOTING
------------------------------------------------------------

ENGINE DOES NOT START
---------------------

• Verify that Windows is 64-bit.
• Run the self-test.
• Make sure rt_engine.exe is not blocked by Windows.
• Check Windows security/firewall notifications.


NO LIVE PACKETS
---------------

• Verify that Npcap is installed.
• Check that the correct network interface is selected.
• Try running the engine with appropriate Windows privileges.
• Verify that the selected interface is active.


DASHBOARD DOES NOT SHOW LIVE DATA
----------------------------------

• Make sure the Local Engine is running.
• Verify that the dashboard is connected to the
  Cryptoscope cloud infrastructure.
• Check your internet connection.
• Restart the engine and dashboard.


------------------------------------------------------------
CRYPTOSCOPE
------------------------------------------------------------

Hybrid Local + Cloud Cybersecurity Platform

Local Engine:
    C++ Real-Time Network Monitoring

Cloud Processing:
    Python-Based PCAP Forensic Analysis

Dashboard:
    Cryptoscope Security & Forensics Dashboard

Purpose:
    Network Monitoring • Cryptographic Forensics •
    Threat Detection • Security Assessment

============================================================
                    END OF README
============================================================